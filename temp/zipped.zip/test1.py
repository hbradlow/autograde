#!/usr/bin/python
def foo():
    import sys
    sys.stdout.write('test1 passed')

