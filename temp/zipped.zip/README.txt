----------description
#COURSENUMBER
CS194
#COURSENAME
Educational Technology
#DESCRIPTION
Example project specification for the autograder. 
The description can be multiple lines
#TITLE
Example Project
#INSTRUCTORS
Kristin Stephens
Dawn Song
#MAX_SUBMISSIONS
5
----------dependencies
----------tests
test_code
----------verification
test_code/verify.py
----------student
student_folder
/”student_file[0-9]\.(py|rb|cpp)”
/”other_student_file\.py”
folder_2
/”regex”
