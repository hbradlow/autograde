#!/usr/bin/python
def bar():
    print 'test2 passed'
