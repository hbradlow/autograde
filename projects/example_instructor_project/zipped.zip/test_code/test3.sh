#!/bin/bash
echo "test3 passed"
